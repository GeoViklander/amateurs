// comentário no javascript
//
// INSTRUÇÕES NO JAVASCRIPT
// comando();
print();

// comando(parametro);
alert("TESTE");

// contexto.comando(parametro);
console.log("BLOG DA FORD");
document.getElementsByTagName()

// ARMAZENAMENTO NO JAVASCRIPT
// var chave = "valor";

var escola = "Caelum";
var nome = "Leonardo";
var idade = 37;
var magro = false;
var altura = 1.89;
