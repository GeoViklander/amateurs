/*
Javascript - Linguagem de Programação

// 2 Camadas
// Armazenamento

var chave = "valor";

// Instruções

comando();
comando(param);

*/
var mensagem = "<br>Boa Noite!";
document.write(mensagem);

